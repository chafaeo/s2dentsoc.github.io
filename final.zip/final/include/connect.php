<?php
	include 'config.php';
	$connect=mysql_connect(HOST,USER,PASSWORD); 

	mysql_select_db(DBNAME);
	
?>