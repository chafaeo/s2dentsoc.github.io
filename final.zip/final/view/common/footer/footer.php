<div class="footer" style="background-color:#2c4c7d;width:100%; height:30px;">
        	
</div>