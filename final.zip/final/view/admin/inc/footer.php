<div class="col-sm-12" style="padding: 30px;text-align: center;">
        <p>&copy<?php echo date('Y');?></p>   
</div>

    <!-- Morris Charts JavaScript -->
    <script src="<?php echo BASE_URL;?>admin/js/plugins/morris/raphael.min.js"></script>
    <script src="<?php echo BASE_URL;?>admin/js/plugins/morris/morris.min.js"></script>
    <script src="<?php echo BASE_URL;?>admin/js/plugins/morris/morris-data.js"></script>

</body>

</html>
