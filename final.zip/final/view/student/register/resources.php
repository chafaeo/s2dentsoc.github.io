<!-- styles here -->
<link rel="stylesheet" href="../../../resources/bootstrap/css/bootstrap.min.css" type="text/css" />
<link rel="stylesheet" href="../../../resources/assets/css/signup-form.css" type="text/css" />



<!-- scripts here -->
<script src="../../../resources/bootstrap/js/bootstrap.min.js"></script>
<script src="../../../resources/assets/jquery/jquery-1.11.2.min.js"></script>
<script src="../../../resources/assets/jquery/jquery.validate.min.js"></script>
<script src="../../../resources/js/student/script.js"></script>