<!DOCTYPE html>
<html>
<head>
	<?php
		include 'resources.php';
	?>
</head>
<body onload="getSkills()">
	<div class="col-lg-12" id="skill-container">
									
	</div>
</body>
</html>