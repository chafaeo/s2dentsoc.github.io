
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">

<title>Home</title>


<!-- styles -->
	<!-- Bootstrap Core CSS -->
    <link href="../../../resources/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    
    <!-- Bootstrap Core CSS -->
    <link href="../../../resources/css/home/bootstrap.min.css" rel="stylesheet">

    <!-- w3.CSS -->
    <link href="../../../resources/css/w3schools/w3.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="../../../resources/css/home/sb-admin.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="../../../resources/css/home/jobs/styles.css" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="../../../resources/assets/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">


<!-- scripts -->
    <script src="../../../resources/js/home/jquery.js"></script>
    <script src="../../../resources/js/home/scripts.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="../../../resources/js/home/bootstrap.min.js"></script>